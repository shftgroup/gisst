#!/bin/zsh
export GISST_CONFIG_PATH=../config
uuid_0=00000000000000000000000000000000
uuid_1=00000000000000000000000000000001

../target/debug/gisst-cli object delete $uuid_0
../target/debug/gisst-cli object delete $uuid_1
../target/debug/gisst-cli instance delete $uuid_0
../target/debug/gisst-cli environment delete $uuid_0
../target/debug/gisst-cli work delete $uuid_0
