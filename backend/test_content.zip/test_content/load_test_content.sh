#!/bin/sh
export GISST_CONFIG_PATH=../config
uuid_0=00000000000000000000000000000000
uuid_1=00000000000000000000000000000001
uuid_2=00000000000000000000000000000002
uuid_3=00000000000000000000000000000003
cargo build --bin gisst-cli
../target/debug/gisst-cli creator create --json-string '{"creator_id":"00000000000000000000000000000000","creator_username":"Joe","creator_full_name":"Joe"}'
../target/debug/gisst-cli work create --json-file test_bfight_work.json
../target/debug/gisst-cli environment create --json-file test_bfight_environment.json
../target/debug/gisst-cli instance create --json-file test_bfight_instance.json
../target/debug/gisst-cli object create -i --force-uuid $uuid_0 --link $uuid_0 --role content bfight.nes
../target/debug/gisst-cli object create -i --force-uuid $uuid_1 --link $uuid_0 --role config retroarch.cfg
../target/debug/gisst-cli state create --force-uuid $uuid_0 --link $uuid_0 --file bfight.entry_state --name "Balloon Fight Test State"
../target/debug/gisst-cli replay create --force-uuid $uuid_0 --link $uuid_0 --file bfight.replay1

../target/debug/gisst-cli work create --json-file test_snake_work.json
../target/debug/gisst-cli environment create --json-file test_snake_environment.json --environment-config-string '{"bios":{"url":"seabios.bin"},"vga_bios":{"url":"vgabios.bin"},"fda":{"url":"$CONTENT","async":true}}'
../target/debug/gisst-cli instance create --json-file test_snake_instance.json
../target/debug/gisst-cli object create -i --force-uuid $uuid_2 --link $uuid_1 --role content freedos722.img
../target/debug/gisst-cli state create --force-uuid $uuid_1 --link $uuid_1 --file state0.v86state --name "Snake Test State"
../target/debug/gisst-cli replay create --force-uuid $uuid_1 --link $uuid_1 --file replay0.v86replay
